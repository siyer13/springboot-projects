package com.axis.demo.demoservice.service;

import com.axis.demo.demoservice.model.Customer;

public interface CustomerService {

    Customer getCustomerByEmail(String email);
    String createCustomer(Customer customer);
}
