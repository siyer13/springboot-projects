package com.axis.demo.demoservice;

public class CustomerException extends Exception {

}
