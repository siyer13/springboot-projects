package com.axis.demo.demoservice.repository;

//@Repository
//public interface CustomerRepository extends JpaRepository<CustomerRepository, String> {
//
//}


public interface CustomerRepository {

}