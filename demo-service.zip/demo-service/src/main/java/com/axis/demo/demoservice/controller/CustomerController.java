package com.axis.demo.demoservice.controller;

import com.axis.demo.demoservice.model.Customer;
import com.axis.demo.demoservice.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1")
public class CustomerController {

    private CustomerService customerService;

    @Autowired
    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping
    public Customer getCustomerByEmail(@RequestParam String email) {
        return customerService.getCustomerByEmail(email);
    }

    @PostMapping
    public String createCustomer(@RequestBody Customer customer) {
        return customerService.createCustomer(customer);
    }
}


