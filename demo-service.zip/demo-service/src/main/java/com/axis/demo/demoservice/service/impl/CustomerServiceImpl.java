package com.axis.demo.demoservice.service.impl;

import com.axis.demo.demoservice.CustomerException;
import com.axis.demo.demoservice.dao.CustomerDAO;
import com.axis.demo.demoservice.model.Customer;
import com.axis.demo.demoservice.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {


    private CustomerDAO customerDAO;

    @Autowired
    public CustomerServiceImpl(CustomerDAO customerDAO) {
        this.customerDAO = customerDAO;
    }

    @Override
    public Customer getCustomerByEmail(String email) {
        return customerDAO.getCustomerByEmail(email);
    }

    @Override
    public String createCustomer(Customer customer) {
        try {
            customerDAO.createCustomer(customer);
            return "Customer created successfully";
        } catch (CustomerException e) {
            return "Error creating customer, please try again";
        }
    }
}
