package com.axis.demo.demoservice.dao;

import com.axis.demo.demoservice.CustomerException;
import com.axis.demo.demoservice.model.Customer;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerDAO {

    public Customer getCustomerByEmail(String email) {
        Customer customer = new Customer();
        customer.setCustomerId("1234");
        customer.setFirstName("abc");
        customer.setLastName("def");
        customer.setPhone("323-001-007");
        customer.setEmail("abc@gmail.com");
        return customer;
    }

    public void createCustomer(Customer customer) throws CustomerException {
        Customer cust = new Customer();
        cust.setEmail(customer.getEmail());
        System.out.print("Email: " + cust.getEmail());
    }
}
