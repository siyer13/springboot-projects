package com.axis.demo.demoservice.common;

import com.axis.demo.demoservice.model.Customer;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import static io.cucumber.spring.CucumberTestContext.SCOPE_CUCUMBER_GLUE;

@Component
@Scope(SCOPE_CUCUMBER_GLUE)
public class HttpClient {

    private final String SERVER_URL = "http://localhost";
    private final String ENDPOINT = "/demo/v1";

    @LocalServerPort
    private int port;
    private final RestTemplate restTemplate = new RestTemplate();

    private String endPoint() {
        return SERVER_URL + ":" + port + ENDPOINT;
    }

    public String getCustomerFirstName(final String email) {
        String abc = restTemplate.postForEntity(endPoint(), email, Customer.class).toString();
        System.out.print("ABC: " + abc);
        return abc;
    }
}
