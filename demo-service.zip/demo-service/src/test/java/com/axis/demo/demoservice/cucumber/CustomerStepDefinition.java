package com.axis.demo.demoservice.cucumber;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class CustomerStepDefinition extends HttpClient {

    private final Logger log = LoggerFactory.getLogger(CustomerStepDefinition.class);

    @Autowired
    private HttpClient httpClient;

    @Given("^the customer email (\\w+)$")
    public void emailProvided(final String email) {
        httpClient.getCustomerByEmail(email);
    }

    @When("^email is not null$")
    public void emailIS(final String email) {
        assertNotNull(email);
    }

    @Then("^customer name should be (\\w+)$")
    public void firstNameShouldBe(final String firstName) {
        assertEquals(firstName, "abc");
    }
}
