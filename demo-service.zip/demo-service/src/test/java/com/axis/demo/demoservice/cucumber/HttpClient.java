package com.axis.demo.demoservice.cucumber;

import com.axis.demo.demoservice.model.Customer;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.client.RestTemplate;

import static io.cucumber.spring.CucumberTestContext.SCOPE_CUCUMBER_GLUE;

@Component
@Scope(SCOPE_CUCUMBER_GLUE)
@ContextConfiguration
@CucumberContextConfiguration
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class HttpClient {

    private final String SERVER_URL = "http://localhost";
    private final String ENDPOINT = "/demo/v1";

    @LocalServerPort
    private int port;
    private final RestTemplate restTemplate = new RestTemplate();

    private String endPoint() {
        return SERVER_URL + ":" + port + ENDPOINT;
    }

    public Customer getCustomerByEmail(final String email) {
        String endPoint  = endPoint() + "?email=" + email;
        return restTemplate.getForObject(endPoint, Customer.class);
    }
}
